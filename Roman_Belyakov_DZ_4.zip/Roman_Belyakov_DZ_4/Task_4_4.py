import Utils # Импорт модуля

print(Utils.currency_rates("USD")) # Проверка работы модуля
print(Utils.currency_rates("eur"))
print(Utils.currency_rates("GBP"))
print(Utils.currency_rates("DKK"))
print(Utils.currency_rates("INR"))
print(Utils.currency_rates("SNR"))
print(Utils.currency_rates("CAD"))





76.0509
54.0798
87.1163
29.5194
None
PS D:\OneDrive\Рабочий стол\Обучение GeekBrains\Задания\Git. Базовый курс\Home Task\Roman_Belyakov_DZ_4> python Task_4_4.py
76.0509
87.1163
103.2771
11.7025
1.01789
None
59.8779
PS D:\OneDrive\Рабочий стол\Обучение GeekBrains\Задания\Git. Базовый курс\Home Task\Roman_Belyakov_DZ_4>



